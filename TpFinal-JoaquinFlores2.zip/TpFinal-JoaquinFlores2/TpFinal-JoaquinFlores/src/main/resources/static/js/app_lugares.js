const API_LUGARES = "http://localhost:8080/api/lugares";

function cargarLugares() {
    fetch(API_LUGARES)
        .then(res => res.json())
        .then(lugares => {
            const tbody = document.getElementById("tabla-lugares");
            if (!tbody) return;
            let html = "";
            lugares.forEach(l => {
                const id = l.idLugar ?? l.id;
                html += `<tr>
                    <td>${id ?? ""}</td>
                    <td>${l.nombre ?? ""}</td>
                    <td>${l.direccion ?? ""}</td>
                    <td>${l.capacidad ?? ""}</td>
                    <td>
                        <button class="btn btn-sm btn-primary me-1" onclick="editarLugar(${id})">Editar</button>
                        <button class="btn btn-sm btn-danger" onclick="eliminarLugar(${id})">Eliminar</button>
                    </td>
                </tr>`;
            });
            tbody.innerHTML = html;
        })
        .catch(err => console.error("Error cargando lugares:", err));
}

function eliminarLugar(id) {
    if (!confirm("¿Seguro que querés eliminar este lugar?")) return;

    fetch(`${API_LUGARES}/${id}`, { method: "DELETE" })
        .then(res => {
            if (!res.ok) {
                return res.text().then(msg => {
                    throw new Error(msg || "Error al eliminar");
                });
            }
            alert("Lugar eliminado");
            cargarLugares();
        })
        .catch(err => {
            console.error(err);
            alert("No se pudo eliminar el lugar. Recordá que no se puede eliminar si tiene eventos asociados.");
        });
}

function editarLugar(id) {
    window.location.href = `crear_lugar.html?id=${id}`;
}

function initFormularioLugar() {
    const form = document.getElementById("form-crear");
    if (!form) return;

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (id) {
        // EDICIÓN
        fetch(`${API_LUGARES}/${id}`)
            .then(res => res.json())
            .then(l => {
                document.getElementById("nombre").value = l.nombre ?? "";
                document.getElementById("direccion").value = l.direccion ?? "";
                document.getElementById("capacidad").value = l.capacidad ?? 10;
            });

        form.addEventListener("submit", e => {
            e.preventDefault();
            const nombre = document.getElementById("nombre").value;
            const direccion = document.getElementById("direccion").value;
            const capacidad = parseInt(document.getElementById("capacidad").value) || 10;

            fetch(`${API_LUGARES}/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nombre, direccion, capacidad })
            })
                .then(res => {
                    if (!res.ok) return res.text().then(t => { throw new Error(t); });
                    alert("Lugar actualizado");
                    window.location.href = "listar_lugares.html";
                })
                .catch(err => {
                    console.error(err);
                    alert(err.message || "No se pudo actualizar el lugar");
                });
        });
    } else {
        // CREACIÓN
        form.addEventListener("submit", e => {
            e.preventDefault();
            const nombre = document.getElementById("nombre").value;
            const direccion = document.getElementById("direccion").value;
            const capacidad = parseInt(document.getElementById("capacidad").value) || 10;

            fetch(API_LUGARES, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nombre, direccion, capacidad })
            })
                .then(res => {
                    if (!res.ok) return res.text().then(t => { throw new Error(t); });
                    alert("Lugar creado");
                    window.location.href = "listar_lugares.html";
                })
                .catch(err => {
                    console.error(err);
                    // Acá te va a aparecer el mensaje de la regla de negocio, ej:
                    // "La capacidad mínima de un lugar debe ser 10 personas"
                    alert(err.message || "Error al crear el lugar");
                });
        });
    }
}

// SEPARAMOS LAS FUNCIONES POR PAGINA

document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("tabla-lugares")) {
        cargarLugares();
    }
    if (document.getElementById("form-crear")) {
        initFormularioLugar();
    }

});
