const API_EVENTOS = "http://localhost:8080/api/eventos";
const API_LUGARES = "http://localhost:8080/api/lugares";
const API_BANDAS = "http://localhost:8080/api/bandas";

async function cargarLugares() {
    try {
        const resp = await fetch(API_LUGARES);
        const lugares = await resp.json();

        //console.log("lugares obtenidos:", lugares);

        const selectLugar = document.getElementById("lugar");
        selectLugar.innerHTML = '<option disabled selected>Seleccione un lugar</option>';

        lugares.forEach(lugar => {
            let opt = document.createElement("option");
            opt.value = lugar.idLugar;          // ← IMPORTANTE!!
            opt.textContent = lugar.nombre;
            selectLugar.appendChild(opt);
        });

    } catch (error) {
        console.error("Error cargando lugares:", error);
    }
}

async function cargarBandas() {
    try {
        const resp = await fetch(API_BANDAS);
        const bandas = await resp.json();

        const bandasSelect = document.getElementById("bandasSelect");
        bandasSelect.innerHTML = "";

        bandas.forEach(b => {
            const id = b.idBanda ?? b.id;
            const opt = document.createElement("option");
            opt.value = id;
            opt.textContent = `${b.nombre} - ${b.genero}`;
            bandasSelect.appendChild(opt);
        });
    } catch (error) {
        console.error("Error cargando bandas:", error);
    }
}

function initFormularioEvento() {
    const form = document.getElementById("form-crear");
    if (!form) return;

    form.addEventListener("submit", e => {
        e.preventDefault();

        const nombreEvento = document.getElementById("nombreEvento").value;
        const fecha = document.getElementById("fecha").value;
        const lugarId = document.getElementById("lugar").value;   // <-- corregido!!

        const bandasSel = Array.from(document.getElementById("bandasSelect").selectedOptions)
            .map(opt => ({idBanda: parseInt (opt.value)}));

        const payload = {
            nombreEvento,
            fecha,
            //lugar: { idLugar: parseInt(lugarId) },
          //  bandas: bandasSel.map(id => ({ idBanda: parseInt(id) }))
            bandas: bandasSel
        };


        // SI EL USUARIO SELECCIONA UN LUGAR → recién ahí lo agregamos
/* if (lugarId && lugarId !== "" && !isNaN(parseInt(lugarId))) {
    payload.lugar = { idLugar: parseInt(lugarId) };
} */

         if (lugarId) payload.lugar = { idLugar: parseInt(lugarId) };

        fetch(API_EVENTOS, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        })
           // .then(res => res.ok ? res.json() : Promise.reject(res))
            .then(res => {
                if (!res.ok) throw new Error("Error al crear evento");
                return res.json();
            })
            .then(() => {
                alert("Evento creado");
                window.location.href = "listar_eventos.html";
            })
            .catch(err => {
                console.error("Error al crear evento:", err);
                alert("No se pudo crear el evento");
            });
    });
}

document.addEventListener("DOMContentLoaded", () => {
    cargarLugares();
    cargarBandas();
    initFormularioEvento();
    
});
