const API_EVENTOS = "http://localhost:8080/api/eventos";

function cargarEventos() {
    fetch(API_EVENTOS)
        .then(res => res.json())
        .then(eventos => {
            const tbody = document.getElementById("tabla-eventos");
            if (!tbody) return;
            let html = "";
            eventos.forEach(ev => {
                const id = ev.idEvento ?? ev.id;
                const lugarNombre = ev.lugar ? (ev.lugar.nombre ?? "") : "";
                const bandas = (ev.bandas || []).map(b => b.nombre ?? "").join(", ");
                html += `<tr>
                    <td>${id ?? ""}</td>
                    <td>${ev.nombreEvento ?? ""}</td>
                    <td>${ev.fecha ?? ""}</td>
                    <td>${lugarNombre}</td>
                    <td>${bandas}</td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="eliminarEvento(${id})">Eliminar</button>
                    </td>
                </tr>`;
            });
            tbody.innerHTML = html;
        })
        .catch(err => console.error("Error cargando eventos:", err));
}

function eliminarEvento(id) {
    if (!confirm("¿Seguro que querés eliminar este evento?")) return;

    fetch(`${API_EVENTOS}/${id}`, { method: "DELETE" })
        .then(res => {
            if (!res.ok) return res.text().then(t => { throw new Error(t); });
            alert("Evento eliminado");
            cargarEventos();
        })
        .catch(err => {
            console.error(err);
            alert(err.message || "No se pudo eliminar el evento");
        });
}

document.addEventListener("DOMContentLoaded", () => {
    cargarEventos();

// Cargar lugares y bandas para el formulario prueba
function cargarLugares() {
    fetch("http://localhost:8080/api/lugares")
        .then(res => res.json())
        .then(lugares => {
            const select = document.getElementById("select-lugar");
            if (!select) return;

            select.innerHTML = '<option value="">Seleccionar lugar...</option>';

            lugares.forEach(l => {
                select.innerHTML += `<option value="${l.idLugar}">${l.nombre}</option>`;
            });
        })
        .catch(err => console.error("Error cargando lugares:", err));
}

document.addEventListener("DOMContentLoaded", () => {
    cargarLugares();
});
// Cargar bandas para el formulario prueba

function cargarBandas() {
    fetch("http://localhost:8080/api/bandas")
        .then(res => res.json())
        .then(bandas => {
            const select = document.getElementById("select-bandas");
            if (!select) return;

            select.innerHTML = "";

            bandas.forEach(b => {
                select.innerHTML += `<option value="${b.idBanda}">${b.nombre}</option>`;
            });
        })
        .catch(err => console.error("Error cargando bandas:", err));
}

document.addEventListener("DOMContentLoaded", () => {
    cargarBandas();
});

});
