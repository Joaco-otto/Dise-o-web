/* const API_BANDAS = "http://localhost:8080/api/bandas";

function cargarBandas() {
    fetch(API_BANDAS)
        .then(res => res.json())
        .then(bandas => {
            const tbody = document.getElementById("tabla-bandas");
            if (!tbody) return;
            let html = "";
            bandas.forEach(b => {
                const id = b.idBanda ?? b.id;
                html += `<tr>
                    <td>${id ?? ""}</td>
                    <td>${b.nombre ?? ""}</td>
                    <td>${b.genero ?? ""}</td>
                    <td>${b.cantidadIntegrantes ?? ""}</td>
                    <td>
                        <button class="btn btn-sm btn-primary me-1" onclick="editarBanda(${id})">Editar</button>
                        <button class="btn btn-sm btn-danger" onclick="eliminarBanda(${id})">Eliminar</button>
                    </td>
                </tr>`;
            });
            tbody.innerHTML = html;
        })
        .catch(err => console.error("Error cargando bandas:", err));
}
// Eliminar banda

function eliminarBanda(id) {
    if (!confirm("¿Seguro que querés eliminar esta banda?")) return;

    fetch(`${API_BANDAS}/${id}`, { method: "DELETE" })
        .then(res => {
            if (!res.ok) {
                return res.text().then(msg => {
                    throw new Error(msg || "Error al eliminar");
                });
            }
            alert("Banda eliminada");
            cargarBandas();
        })
        .catch(err => {
            console.error(err);
            alert("No se pudo eliminar la banda. Recordá que no se puede eliminar si tiene eventos asociados.");
        });
}

// editar banda

function editarBanda(id) {
    // Reuso la misma pantalla de creación, pasando ?id corrregir esto
    window.location.href = `crear_banda.html?id=${id}`;
}
// Inicializar formulario en modo edición si hay id

function initFormularioBanda() {
    const form = document.getElementById("form-crear");
    if (!form) return;

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (!id)return; // Si no hay id, es creación, ya lo maneja api_bandas.js{
        // MODO EDICIÓN
        fetch(`${API_BANDAS}/${id}`)
            .then(res => res.json())
            .then(b => {
                document.getElementById("nombre").value = b.nombre ?? "";
                document.getElementById("genero").value = b.genero ?? "";
                document.getElementById("cantidadIntegrantes").value = b.cantidadIntegrantes ?? 1;
            });

        // guardar edicion

        form.addEventListener("submit", e => {
            e.preventDefault();
            const nombre = document.getElementById("nombre").value;
            const genero = document.getElementById("genero").value;
            const cantidadIntegrantes = parseInt(document.getElementById("cantidadIntegrantes").value) || 1;

            fetch(`${API_BANDAS}/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nombre, genero, cantidadIntegrantes })
            })
                .then(res => {
                    if (!res.ok) throw new Error("Error actualizando banda");
                    alert("Banda actualizada");
                    window.location.href = "listar_bandas.html";
                })
                .catch(err => {
                    console.error(err);
                    alert("No se pudo actualizar la banda");
                });
        });
    }
    // Si NO hay id, la creación ya la maneja api_bandas.js con Axios
  // INIZIALIZAR LA APLICACIÓN

document.addEventListener("DOMContentLoaded", () => {
    // aca separo para que trabaje en pantallas separadas
    if (document.getElementById("tabla-bandas")) {
        cargarBandas();
    }
    if (!document.getElementById("form-crear"))return {
        initFormularioBanda();
    }

}); */
const API_BANDAS = "http://localhost:8080/api/bandas";

// ==============================
// LISTAR BANDAS
// ==============================
function cargarBandas() {
    fetch(API_BANDAS)
        .then(res => res.json())
        .then(bandas => {
            const tbody = document.getElementById("tabla-bandas");
            if (!tbody) return;

            tbody.innerHTML = bandas.map(b => `
                <tr>
                    <td>${b.id ?? b.idBanda ?? b.id_banda ?? "??"}</td>
                    <td>${b.nombre}</td>
                    <td>${b.genero}</td>
                    <td>${b.cantidadIntegrantes}</td>
                    <td>
                         <button class="btn btn-primary btn-sm" onclick="editarBanda(${b.id ?? b.idBanda ?? b.id_banda})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarBanda(${b.id ?? b.idBanda ?? b.id_banda})">Eliminar</button>
                    </td>
                </tr>
            `).join("");
        });
}

// ==============================
// ELIMINAR BANDA
// ==============================
function eliminarBanda(id) {
    if (!confirm("¿Seguro querés eliminar esta banda?")) return;

    fetch(`${API_BANDAS}/${id}`, { method: "DELETE" })
        .then(res => {
            if (!res.ok) return res.text().then(msg => { throw msg; });

            alert("Banda eliminada");
            cargarBandas();
        })
        .catch(err => {
            alert("No se pudo eliminar la banda. Puede estar usada en un evento.");
        });
}

// ==============================
// IR A EDITAR
// ==============================
function editarBanda(id) {
    window.location.href = `crear_banda.html?id=${id}`;
}

// ==============================
// MODO EDICIÓN
// ==============================
function initFormularioBanda() {
    const form = document.getElementById("form-crear");
    if (!form) return;

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (!id) return;

    // Cargar datos de la banda
    fetch(`${API_BANDAS}/${id}`)
        .then(res => res.json())
        .then(b => {
            document.getElementById("nombre").value = b.nombre;
            document.getElementById("genero").value = b.genero;
            document.getElementById("cantidadIntegrantes").value = b.cantidadIntegrantes;
        });

    // Guardar edición
    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const nombre = document.getElementById("nombre").value;
        const genero = document.getElementById("genero").value;
        const cantidadIntegrantes = parseInt(document.getElementById("cantidadIntegrantes").value) || 1;

        fetch(`${API_BANDAS}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nombre, genero, cantidadIntegrantes })
        })
            .then(res => {
                if (!res.ok) throw new Error("Error actualizando banda");
                alert("Banda actualizada");
                window.location.href = "listar_bandas.html";
            })
            .catch(() => alert("No se pudo actualizar la banda"));
    });
}

// ==============================
// INICIALIZAR APP
// ==============================
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("tabla-bandas")) cargarBandas();
    if (document.getElementById("form-crear")) initFormularioBanda();
});
