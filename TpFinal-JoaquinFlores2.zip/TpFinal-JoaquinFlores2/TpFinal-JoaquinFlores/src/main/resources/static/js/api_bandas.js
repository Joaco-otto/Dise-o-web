// Para crear una nueva banda usamos Axios

const API_BANDAS_AXIOS = "http://localhost:8080/api/bandas";

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("form-crear");
    if (!form) return;

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    
    // Si estoy editando → NO usar Axios
    if (id) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const nombre = document.getElementById("nombre").value;
        const genero = document.getElementById("genero").value;
        const cantidadIntegrantes = parseInt(document.getElementById("cantidadIntegrantes").value) || 1;

        try {
            await axios.post(API_BANDAS_AXIOS, { nombre, genero, cantidadIntegrantes });
            alert("Banda creada con éxito");
            window.location.href = "listar_bandas.html";
        } catch (err) {
            console.error(err);
            alert("Error al crear banda");
        }
    });
});