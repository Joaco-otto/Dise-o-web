package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Lugar;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository.I_Lugar;

@Service
public class LugarService {

    @Autowired
    private I_Lugar repo;

    // REGLA DE NEGOCIO 1: capacidad mínima
    private void validarCapacidad(Integer capacidad){
        if(capacidad < 10){
            throw new RuntimeException("La capacidad mínima de un lugar debe ser 10 personas");
        }
    }

    public Lugar crear(Lugar lugar){
        validarCapacidad(lugar.getCapacidad());
        return repo.save(lugar);
    }

    public List<Lugar> listar(){
        return repo.findAll();
    }

    public Lugar buscarPorId(Long id){
        return repo.findById(id)
                   .orElseThrow(() -> new RuntimeException("Lugar no encontrado"));
    }

    public Lugar actualizar(Long id, Lugar data){
        Lugar lugar = buscarPorId(id);
        validarCapacidad(data.getCapacidad());

        lugar.setNombre(data.getNombre());
        lugar.setDireccion(data.getDireccion());
        lugar.setCapacidad(data.getCapacidad());

        return repo.save(lugar);
    }

    // REGLA DE NEGOCIO 2: no eliminar lugares con eventos asociados
    public void eliminar(Long id){
        Lugar lugar = buscarPorId(id);

        if(lugar.getEventos() != null && !lugar.getEventos().isEmpty()){
            throw new RuntimeException("No se puede eliminar un lugar con eventos programados");
        }

        repo.delete(lugar);
    }

    // Query method
    public List<Lugar> buscarConCapacidadMayorA(Integer capacidad){
        return repo.findByCapacidadGreaterThan(capacidad);
    }

}
