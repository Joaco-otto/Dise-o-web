package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEvento;

    private String nombreEvento;
    private LocalDate fecha;

    @ManyToOne
    @JoinColumn(name = "id_lugar")
    private Lugar lugar;

    @ManyToMany
    @JoinTable(
        name = "evento_banda",
        joinColumns = @JoinColumn(name = "id_evento"),
        inverseJoinColumns = @JoinColumn(name = "id_banda")
    )
    private List<Banda> bandas;

}
