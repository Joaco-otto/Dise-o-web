package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Lugar;

public interface I_Lugar extends JpaRepository <Lugar , Long> {
    
    List<Lugar> findByCapacidadGreaterThan(Integer capacidad);

}
