package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Banda;

public interface I_Banda extends JpaRepository <Banda, Long>{


      // Query method obligatorios

    List<Banda> findByGenero(String genero);   

    List<Banda> findByNombreContaining(String nombre); 

}
