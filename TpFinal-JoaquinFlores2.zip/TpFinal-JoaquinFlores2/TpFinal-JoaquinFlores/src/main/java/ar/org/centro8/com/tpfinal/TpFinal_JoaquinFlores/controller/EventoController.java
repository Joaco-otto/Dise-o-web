package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Evento;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.service.EventoService;

@RestController
@RequestMapping("/api/eventos")
@CrossOrigin(origins = "*")
public class EventoController {

    @Autowired
    private EventoService service;

    // ======== CRUD ========

    @GetMapping
    public List<Evento> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Evento buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Evento crear(@RequestBody Evento evento) {
        return service.crear(evento);
    }

    @PutMapping("/{id}")
    public Evento actualizar(@PathVariable Long id, @RequestBody Evento evento) {
        return service.actualizar(id, evento);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    // ======== ENDPOINTS ADICIONALES ========

    @GetMapping("/fecha/{fecha}")
    public List<Evento> buscarPorFecha(
        @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha
    ) {
        return service.buscarPorFecha(fecha);
    }

    @GetMapping("/lugar/{idLugar}")
    public List<Evento> buscarPorLugar(@PathVariable Long idLugar) {
        return service.buscarPorLugar(idLugar);
    }

}
