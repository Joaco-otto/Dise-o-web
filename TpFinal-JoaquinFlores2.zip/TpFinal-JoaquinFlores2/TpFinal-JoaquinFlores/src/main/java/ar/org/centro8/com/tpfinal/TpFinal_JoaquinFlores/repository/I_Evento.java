package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Evento;

public interface I_Evento extends JpaRepository<Evento,Long>{

   // Query methods obligatorios
   
    List<Evento> findByFecha(LocalDate fecha);

    List<Evento> findByLugar_IdLugar(Long idLugar);
}
