package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ViewController {

    /* @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/crear_evento")
    public String crearEvento() {
        return "crear_evento";
    }

    @GetMapping("/listar_eventos")
    public String listarEventos() {
        return "listar_eventos";
    }

    @GetMapping("/crear_banda")
    public String crearBanda() {
        return "crear_banda";
    }

    @GetMapping("/listar_bandas")
    public String listarBandas() {
        return "listar_bandas";
    }

    @GetMapping("/crear_lugar")
    public String crearLugar() {
        return "crear_lugar";
    }

    @GetMapping("/listar_lugares")
    public String listarLugares() {
        return "listar_lugares";
    } */
}


