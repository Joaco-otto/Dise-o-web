package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Lugar;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.service.LugarService;
@RestController
@RequestMapping("/api/lugares")
@CrossOrigin(origins = "*")
public class LugarController {


    @Autowired
    private LugarService service;

    // ======== CRUD ========

    @GetMapping
    public List<Lugar> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Lugar buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Lugar crear(@RequestBody Lugar lugar) {
        return service.crear(lugar);
    }

    @PutMapping("/{id}")
    public Lugar actualizar(@PathVariable Long id, @RequestBody Lugar lugar) {
        return service.actualizar(id, lugar);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    // ======== ENDPOINTS ADICIONALES ========

    @GetMapping("/capacidad/{min}")
    public List<Lugar> buscarPorCapacidadMayor(@PathVariable Integer min) {
        return service.buscarConCapacidadMayorA(min);
    }


}
