package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Banda;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository.I_Banda;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Service
@Data
@NoArgsConstructor
@AllArgsConstructor

public class BandaService {
    
    @Autowired

    private I_Banda repo;

    // regla de negocio 1 -- Evitar bandas duplicadas

    public Banda crearBanda(Banda banda){
        if(repo.findByNombreContaining(banda.getNombre()).size()>0){
            throw new RuntimeException("Ya existe una banda con ese nombre");
        }
        return repo.save(banda);
    }

     public List<Banda> listar(){
        return repo.findAll();
  }
  public Banda buscarPorId(Long id){
        return repo.findById(id)
                   .orElseThrow(() -> new RuntimeException("Banda no encontrada"));
    }

    public Banda actualizar(Long id, Banda data){
        Banda banda = buscarPorId(id);

        banda.setNombre(data.getNombre());
        banda.setGenero(data.getGenero());
        banda.setCantidadIntegrantes(data.getCantidadIntegrantes());

        return repo.save(banda);
    }


  // regla de negocio 2 -- No eliminar bandas con eventos programados

  public void eliminar(Long id){
        Banda banda = repo.findById(id)
                          .orElseThrow(() -> new RuntimeException("No encontrada"));

        if(banda.getEventos() != null && !banda.getEventos().isEmpty()){
            throw new RuntimeException("No se puede eliminar: tiene eventos asociados");
        }

        repo.delete(banda);
    }
// Métodos usando query method
    public List<Banda> buscarPorGenero(String genero){
        return repo.findByGenero(genero);
    }

    public List<Banda> buscarPorNombre(String nombre){
        return repo.findByNombreContaining(nombre);
    }

}
