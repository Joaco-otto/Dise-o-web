package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Banda;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Evento;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.model.Lugar;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository.I_Banda;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository.I_Evento;
import ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores.repository.I_Lugar;
@Service
public class EventoService {

    @Autowired
    private I_Evento repo;

    @Autowired
    private I_Lugar repoLugar;
    @Autowired
    private I_Banda repoBanda;

    // REGLA DE NEGOCIO 1: fecha del evento no puede ser pasada
    private void validarFecha(LocalDate fecha){

        if(fecha == null) 
            throw new RuntimeException("La fecha no puede ser nula");

        if(fecha.isBefore(LocalDate.now())){
            throw new RuntimeException("La fecha del evento no puede ser anterior a hoy");
        }
    }
    // validaciones 
    // REGLA DE NEGOCIO 2: el lugar debe existir y tener capacidad > 0
    private void validarLugar(Long idLugar){
        Lugar lugar = repoLugar.findById(idLugar)
                .orElseThrow(() -> new RuntimeException("Lugar no encontrado"));

        if(lugar.getCapacidad() <= 0){
            throw new RuntimeException("El lugar no tiene capacidad disponible");
        }
    }

    private Lugar cargarLugar(Evento evento){
        if(evento.getLugar() == null || evento.getLugar().getIdLugar() == null)
            return null;

        return repoLugar.findById(evento.getLugar().getIdLugar())
                .orElseThrow(() -> new RuntimeException("Lugar no encontrado"));
    }

    private List<Banda> cargarBandas(Evento evento){
        if(evento.getBandas() == null) return List.of();

        return evento.getBandas().stream()
                .map(b -> {
            if (b == null || b.getIdBanda() == null) {
                throw new RuntimeException("Una banda del evento no tiene ID. Debes mandar { \"idBanda\": X }");
            }
            return repoBanda.findById(b.getIdBanda())
                .orElseThrow(() -> new RuntimeException("Banda no encontrada: " + b.getIdBanda()));
        })
        .toList();
    }


    // ================= CRUD =================

    public Evento crear(Evento evento){
        validarFecha(evento.getFecha());
        Lugar lugar = cargarLugar(evento);
        List<Banda> bandas = cargarBandas(evento);

        evento.setLugar(lugar);
        evento.setBandas(bandas);

        return repo.save(evento);
    }


      //  validarLugar(evento.getLugar().getIdLugar());
     /*   if (evento.getLugar() != null && evento.getLugar().getIdLugar() != null) {
        validarLugar(evento.getLugar().getIdLugar());
    } else {
        evento.setLugar(null);  // Asegura que se guarde como NULL
    }
      
      return repo.save(evento);
    } */

    public List<Evento> listar(){
        return repo.findAll();
    }

    public Evento buscarPorId(Long id){
        return repo.findById(id)
                   .orElseThrow(() -> new RuntimeException("Evento no encontrado"));
    }

    public Evento actualizar(Long id, Evento data){
        Evento evento = buscarPorId(id);

        validarFecha(data.getFecha());
       // validarLugar(data.getLugar().getIdLugar());

       // aqui comento para ver el tema de evento
       /* if (data.getLugar() != null && data.getLugar().getIdLugar() != null) {
        validarLugar(data.getLugar().getIdLugar());
        evento.setLugar(data.getLugar());
    } else {
        evento.setLugar(null);
    } */

        evento.setNombreEvento(data.getNombreEvento());
        evento.setFecha(data.getFecha());
        //evento.setLugar(data.getLugar());
        //evento.setBandas(data.getBandas());

        return repo.save(evento);
    }

    public void eliminar(Long id){
        repo.delete(buscarPorId(id));
    }

    // Query Methods
    public List<Evento> buscarPorFecha(LocalDate fecha){
        return repo.findByFecha(fecha);
    }

    public List<Evento> buscarPorLugar(Long idLugar){
        return repo.findByLugar_IdLugar(idLugar);
    }

}
