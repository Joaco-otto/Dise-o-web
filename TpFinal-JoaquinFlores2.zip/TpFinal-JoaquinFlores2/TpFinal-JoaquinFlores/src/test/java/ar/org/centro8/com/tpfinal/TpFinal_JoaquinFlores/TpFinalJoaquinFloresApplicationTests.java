package ar.org.centro8.com.tpfinal.TpFinal_JoaquinFlores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpFinalJoaquinFloresApplicationTests {

	@Test
	void contextLoads() {
	}

}
