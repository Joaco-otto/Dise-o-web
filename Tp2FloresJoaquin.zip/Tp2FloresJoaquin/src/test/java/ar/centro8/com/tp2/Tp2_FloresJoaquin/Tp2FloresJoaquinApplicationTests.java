package ar.centro8.com.tp2.Tp2_FloresJoaquin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp2FloresJoaquinApplicationTests {

	@Test
	void contextLoads() {
	}

}
