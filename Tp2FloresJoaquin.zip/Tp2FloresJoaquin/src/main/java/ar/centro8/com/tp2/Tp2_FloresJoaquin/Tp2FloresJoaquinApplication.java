package ar.centro8.com.tp2.Tp2_FloresJoaquin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp2FloresJoaquinApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp2FloresJoaquinApplication.class, args);
	}

}
